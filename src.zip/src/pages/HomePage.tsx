import { GameField } from "../components/GameField/GameField"

export const HomePage = () => {
  return (
    <div className="page">
      <GameField />
    </div>
  )
}
